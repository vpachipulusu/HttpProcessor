﻿using Products.Domain.DataModels.Product;
using Products.Service.Services.Base;

namespace Products.Service.Services.Interfaces
{
    public interface IProductBaseService : IBaseService<ProductBase>
    {

    }
}

﻿namespace Products.Domain.Dto
{
    public class DbConfig
    {
        public string DefaultDatabase { get; set; }
    }
}

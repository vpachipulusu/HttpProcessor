﻿using System.ComponentModel.DataAnnotations;

namespace Products.Domain.Authentication
{
    public class AuthenticateRequest
    {
        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }
    }
}

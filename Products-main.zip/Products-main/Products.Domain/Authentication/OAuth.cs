﻿namespace Products.Domain.Authentication
{
    public class OAuth
    {
        public string Secret { get; set; }
    }
}
